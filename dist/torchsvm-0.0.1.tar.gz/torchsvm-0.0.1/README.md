# fitting_machine

A minimal Python package demonstrating how to structure and train a simple 
scikit-learn model.

## Installation

1. Clone or download the repo (or use the provided `.zip`).
2. (Optional) Create and activate a virtual environment.
3. Install the package in editable mode:
   ```bash
   pip install -e .
